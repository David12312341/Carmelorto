# /static Folder

This folder contains all of the static files that should be served to users. This includes `.css` and `.js` files.
